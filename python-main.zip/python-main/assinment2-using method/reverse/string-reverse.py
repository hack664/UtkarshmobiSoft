def rev():
    print("\n---Answer 1---")
    str="Python Skills"
    print("\nOriginal string: ",str)
    print("\nReversed string: ",str[::-1])