  
def avg():
    print("\n---Answer 3---")
    avg=1000
    e1=1100
    e2=500
    e3=(avg*3)-(e1+e2)
    print("\nFirst employee salary = ",e1,"\nSecond employee salary =",e2,"\nThird employee salary = ",e3,"\nAverage =",)