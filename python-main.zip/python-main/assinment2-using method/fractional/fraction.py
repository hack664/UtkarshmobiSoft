  
def frac():
    print("\n---Answer 4---")
    percent=30
    n=percent
    d=100
    num=n/10
    den=d/10
    print("\nConversion of 30 percent into fraction is equal to : ",int(num),"/",int(den))