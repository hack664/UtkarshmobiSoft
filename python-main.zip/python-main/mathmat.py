from mathmat.addition.addition import add 
from mathmat.substraction.substrraction import sub
from mathmat.divisioon.division import div
from mathmat.multiplication.multi import multi


a=add(50,70)
b=sub(90,40)
c=multi(100,10)
d=div(50,5)

print("\nADDITION:",a)
print("\nsubstraction:",b)
print("\ndivision:",c)
print("\nmultiplication:",d)
