x=10

y=5

print ("add :",x+y)

print ("sub  :",x-y)

print ("multi:",x*y)

print ("div :",x/y)

print ("mod :",x%y)

print ("pow :",x**y)