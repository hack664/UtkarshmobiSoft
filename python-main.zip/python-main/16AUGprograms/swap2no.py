#13)program to swap 2 no using temprary variable
X= input("Enter value of X:  ")
Y= input("Enter value of Y:  ")

temp=X
X=Y
Y=temp

print("The value of X after Swaping: ", X)
print("The value of Y after Swaping: ", Y)
