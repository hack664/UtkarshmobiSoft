#12 Write Program to Compute Quotient and Remainder
a=4
b=8
print("Quotient: ",a//b)
print("Remainder",a%b)