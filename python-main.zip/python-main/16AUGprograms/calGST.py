#16)PROGRAM TO CALCULATE GST of 18% on baseprice of 34900


GST =((18/100) * 34900)

print ("GST is :",GST)