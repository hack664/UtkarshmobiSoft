#11)program to find ASCII value of character
a = 'X'
print("The ASCII value of X is", ord(a))

a='x'
print("The ASCII value of x is", ord(a))
