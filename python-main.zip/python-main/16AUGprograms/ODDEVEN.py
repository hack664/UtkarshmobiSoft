#14)program to check no is odd or even

check=int (input("Enter a number: "))
if (check % 2)  ==  0 :
    print("it is EVEN no",check)
else:
     print("it is ODD no",check)