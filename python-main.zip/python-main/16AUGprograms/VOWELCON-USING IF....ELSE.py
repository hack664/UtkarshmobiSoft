#15)PROGRAM O CHECK WHETHER AN ALPHABET IS VOWEL OR CONSONANT USING IF ....ELSE
X='P'

if X in ('a','e','i','e','u') :
    print("The given Alphabet is vowel",X)
else:
    print("The given Alphabet is consonant",X) 