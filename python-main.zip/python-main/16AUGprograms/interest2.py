#18)Program to calculate simple intrest and cvoumound intrest (5%/month) n amount -161258
a=161258
Y3=a/36
Y5=a/60

EMI3=Y3+(0.05*Y3)
EMI5=Y5+(0.05*Y5)

print("EMI FOR 3 YEARS WITH INREST5%:",EMI3)
print("EMI FOR 5 YEARS WITH INREST5%:",EMI5)
