import os

print("stat is "+str(os.stat("E:")))