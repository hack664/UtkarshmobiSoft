from tkinter import *
win=Tk()
win.geometry("200x200+100+200")
w=Label(win,text="Hello,Welcome to GUI...")
w.pack()
win.mainloop()