import tkinter as tk
win=tk.Tk(className="nikk")
win.mainloop()