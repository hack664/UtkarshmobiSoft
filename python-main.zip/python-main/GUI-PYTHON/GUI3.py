
  
from tkinter import *
window=Tk()
window.title("My GUI 3")
window.geometry('300x200+10+20')
window.mainloop()