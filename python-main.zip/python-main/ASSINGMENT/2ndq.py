# 2) Assign String to x variable in DD-MM-YYYY format extract and print year from string


x="24-11-2003"

#printing year from string

print ("printing year from string",x[6:])