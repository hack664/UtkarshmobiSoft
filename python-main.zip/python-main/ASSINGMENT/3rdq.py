# 3) In a small company, the average salary of three employees is Rs1000 per week. If one employee earns Rs1100 and other
#  earns Rs500, how much will the third employee earn? Solve by using python programming

x=0 
y=0
z=0


print("TOTAL SALARY FOR 3 EMPLOYEES 1000*3 :")
x=1000*3
print(x)

print("SALARY FOR 2 EMPLOYEES IS 1100+500:")
y=1100+500
print(y)

print("SALARY OF 3RD EMPLOYEE IS 3000-1600:")
z=3000-1600
print(z)