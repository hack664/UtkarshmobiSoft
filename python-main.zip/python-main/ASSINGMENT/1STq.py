# 1) Reverse a String and print it on console "Python Skills"

str="Python Skills"
print("\nOriginal string: ",str)
print("\nReversed string: ",str[::-1])