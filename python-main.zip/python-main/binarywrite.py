f=open("test.txt",'wb')
f.write(b"program for testing binary write operation")
f.close()